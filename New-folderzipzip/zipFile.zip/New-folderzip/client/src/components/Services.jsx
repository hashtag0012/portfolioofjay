import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { 
  Globe, 
  ShoppingCart, 
  Palette, 
  Plug, 
  Wrench, 
  Headphones,
  ArrowUpRight
} from 'lucide-react';

const services = [
  {
    icon: Globe,
    title: "Website Development",
    description: "Custom business websites, landing pages & portfolios built for speed and conversion.",
    tags: ["Business Sites", "Landing Pages", "Responsive"],
    number: "01"
  },
  {
    icon: ShoppingCart,
    title: "WordPress & eCommerce",
    description: "Professional WordPress sites, WooCommerce & Shopify stores ready to sell.",
    tags: ["WordPress", "WooCommerce", "Shopify"],
    number: "02"
  },
  {
    icon: Palette,
    title: "React & UI Development",
    description: "Modern React apps with interactive components, dashboards & slick animations.",
    tags: ["React", "Dashboards", "Animations"],
    number: "03"
  },
  {
    icon: Plug,
    title: "API & Payment Integration",
    description: "Seamless API connections with Stripe, PayPal, Razorpay & third-party tools.",
    tags: ["Stripe", "PayPal", "REST APIs"],
    number: "04"
  },
  {
    icon: Wrench,
    title: "Website Fixes & Optimization",
    description: "Quick bug fixes, speed improvements & UI corrections with fast turnaround.",
    tags: ["Bug Fixes", "Speed", "UI/UX"],
    number: "05"
  },
  {
    icon: Headphones,
    title: "Ongoing Support",
    description: "Reliable maintenance, feature updates & white-label development for agencies.",
    tags: ["Maintenance", "Updates", "White-label"],
    number: "06"
  }
];

const Services = ({ onHover, onLeave }) => {
  const containerRef = useRef(null);
  const isInView = useInView(containerRef, { once: true, margin: "-100px" });

  const containerVariants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 60, scale: 0.95 },
    visible: {
      opacity: 1,
      y: 0,
      scale: 1,
      transition: {
        duration: 0.8,
        ease: [0.16, 1, 0.3, 1]
      }
    }
  };

  return (
    <section id="services" className="services-section" ref={containerRef}>
      <div className="container">
        <motion.div 
          className="section-header"
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        >
          <span className="section-eyebrow">What I Do</span>
          <h2 className="section-title">
            Services that<br />
            <span className="gradient-text">deliver</span> <span className="serif">results</span>
          </h2>
        </motion.div>

        <motion.div 
          className="services-grid"
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
        >
          {services.map((service, index) => (
            <motion.div 
              key={index}
              className="service-card"
              variants={cardVariants}
              onMouseEnter={onHover}
              onMouseLeave={onLeave}
            >
              <div className="service-card-inner">
                <div className="service-number">{service.number}</div>
                
                <div className="service-header">
                  <div className="service-icon-wrapper">
                    <service.icon size={24} strokeWidth={1.5} />
                  </div>
                  <ArrowUpRight className="service-arrow" size={20} />
                </div>

                <h3 className="service-title">{service.title}</h3>
                <p className="service-description">{service.description}</p>

                <div className="service-tags">
                  {service.tags.map((tag, i) => (
                    <span key={i} className="service-tag">{tag}</span>
                  ))}
                </div>

                <div className="service-hover-line"></div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default Services;
