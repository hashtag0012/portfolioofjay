import { useRef, useState } from 'react';
import { motion, useInView, AnimatePresence } from 'framer-motion';
import { ArrowUpRight, ExternalLink } from 'lucide-react';

const projects = [
  {
    id: 1,
    title: "E-Commerce Platform",
    category: "WooCommerce",
    description: "Full-featured online store with custom theme, payment integration, and inventory management system.",
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=1200&h=800&fit=crop",
    tags: ["WordPress", "WooCommerce", "Stripe"],
    year: "2024"
  },
  {
    id: 2,
    title: "SaaS Dashboard",
    category: "React App",
    description: "Analytics dashboard with real-time data visualization, user management, and responsive design.",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=1200&h=800&fit=crop",
    tags: ["React", "Chart.js", "REST API"],
    year: "2024"
  },
  {
    id: 3,
    title: "Agency Landing Page",
    category: "Business Website",
    description: "High-converting landing page with smooth animations, contact forms, and SEO optimization.",
    image: "https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?w=1200&h=800&fit=crop",
    tags: ["HTML/CSS", "JavaScript", "GSAP"],
    year: "2023"
  },
  {
    id: 4,
    title: "Restaurant System",
    category: "Shopify",
    description: "Custom Shopify store with online ordering, table reservations, and loyalty program integration.",
    image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=1200&h=800&fit=crop",
    tags: ["Shopify", "Liquid", "Custom Theme"],
    year: "2023"
  }
];

const Portfolio = ({ onHover, onLeave }) => {
  const containerRef = useRef(null);
  const isInView = useInView(containerRef, { once: true, margin: "-100px" });
  const [hoveredId, setHoveredId] = useState(null);

  const containerVariants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: 0.15
      }
    }
  };

  const projectVariants = {
    hidden: { opacity: 0, y: 80 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.9,
        ease: [0.16, 1, 0.3, 1]
      }
    }
  };

  return (
    <section id="portfolio" className="portfolio-section" ref={containerRef}>
      <div className="container">
        <motion.div 
          className="section-header"
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        >
          <span className="section-eyebrow">Selected Work</span>
          <h2 className="section-title">
            Projects that<br />
            <span className="serif">speak</span> <span className="gradient-text">volumes</span>
          </h2>
        </motion.div>

        <motion.div 
          className="portfolio-grid"
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
        >
          {projects.map((project, index) => (
            <motion.article 
              key={project.id}
              className={`portfolio-item ${hoveredId === project.id ? 'hovered' : ''}`}
              variants={projectVariants}
              onMouseEnter={() => { setHoveredId(project.id); onHover(); }}
              onMouseLeave={() => { setHoveredId(null); onLeave(); }}
            >
              <div className="portfolio-image-container">
                <motion.div 
                  className="portfolio-image"
                  style={{ backgroundImage: `url(${project.image})` }}
                  whileHover={{ scale: 1.05 }}
                  transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
                />
                <div className="portfolio-image-overlay">
                  <motion.div 
                    className="view-project-btn"
                    initial={{ opacity: 0, scale: 0.8 }}
                    whileHover={{ scale: 1.1 }}
                    animate={hoveredId === project.id ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.8 }}
                    transition={{ duration: 0.3 }}
                  >
                    <ExternalLink size={24} />
                  </motion.div>
                </div>
                <div className="portfolio-year">{project.year}</div>
              </div>

              <div className="portfolio-content">
                <div className="portfolio-meta">
                  <span className="portfolio-category">{project.category}</span>
                  <ArrowUpRight className="portfolio-arrow" size={18} />
                </div>
                <h3 className="portfolio-title">{project.title}</h3>
                <p className="portfolio-description">{project.description}</p>
                <div className="portfolio-tags">
                  {project.tags.map((tag, i) => (
                    <span key={i} className="portfolio-tag">{tag}</span>
                  ))}
                </div>
              </div>
            </motion.article>
          ))}
        </motion.div>

        <motion.div 
          className="portfolio-cta"
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.6, ease: [0.16, 1, 0.3, 1] }}
        >
          <div className="cta-content">
            <p>Interested in working together?</p>
            <a 
              href="#contact" 
              className="outline-btn"
              onMouseEnter={onHover}
              onMouseLeave={onLeave}
            >
              <span>Let's Discuss Your Project</span>
              <ArrowUpRight size={16} />
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Portfolio;
