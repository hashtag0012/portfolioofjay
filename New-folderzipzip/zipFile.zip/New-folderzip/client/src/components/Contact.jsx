import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { Mail, MessageCircle, ArrowUpRight, Sparkles } from 'lucide-react';

const Contact = ({ onHover, onLeave }) => {
  const containerRef = useRef(null);
  const isInView = useInView(containerRef, { once: true, margin: "-100px" });

  return (
    <section id="contact" className="contact-section" ref={containerRef}>
      <div className="container">
        <motion.div 
          className="contact-wrapper"
          initial={{ opacity: 0, y: 60 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
        >
          <div className="contact-header">
            <motion.div 
              className="contact-badge"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={isInView ? { opacity: 1, scale: 1 } : {}}
              transition={{ delay: 0.3, duration: 0.6 }}
            >
              <span className="badge-glow"></span>
              <Sparkles size={14} />
              <span>Ready to Start</span>
            </motion.div>
            
            <h2 className="contact-title">
              Let's build<br />
              something <span className="gradient-text">amazing</span>
            </h2>
            
            <p className="contact-description">
              Have a project in mind? Looking for reliable development support? 
              I'm here to help bring your vision to life with fast, quality work.
            </p>
          </div>

          <div className="contact-methods">
            <motion.a 
              href="https://wa.me/1234567890" 
              className="contact-card whatsapp"
              onMouseEnter={onHover}
              onMouseLeave={onLeave}
              whileHover={{ y: -5 }}
              transition={{ duration: 0.3 }}
            >
              <div className="contact-card-icon">
                <MessageCircle size={28} />
              </div>
              <div className="contact-card-content">
                <span className="contact-card-label">WhatsApp</span>
                <span className="contact-card-value">Quick Response</span>
              </div>
              <ArrowUpRight className="contact-card-arrow" size={20} />
              <div className="contact-card-bg"></div>
            </motion.a>

            <motion.a 
              href="mailto:jay@example.com" 
              className="contact-card email"
              onMouseEnter={onHover}
              onMouseLeave={onLeave}
              whileHover={{ y: -5 }}
              transition={{ duration: 0.3 }}
            >
              <div className="contact-card-icon">
                <Mail size={28} />
              </div>
              <div className="contact-card-content">
                <span className="contact-card-label">Email</span>
                <span className="contact-card-value">jay@example.com</span>
              </div>
              <ArrowUpRight className="contact-card-arrow" size={20} />
              <div className="contact-card-bg"></div>
            </motion.a>
          </div>

          <div className="contact-availability">
            <div className="availability-indicator">
              <span className="indicator-dot"></span>
              <span className="indicator-ring"></span>
            </div>
            <span>Currently available for new projects</span>
          </div>

          <div className="contact-decoration">
            <svg className="deco-svg" viewBox="0 0 200 200" fill="none">
              <motion.circle 
                cx="100" cy="100" r="80" 
                stroke="url(#contactGrad)" 
                strokeWidth="0.5"
                initial={{ pathLength: 0, opacity: 0 }}
                animate={isInView ? { pathLength: 1, opacity: 1 } : {}}
                transition={{ duration: 2, delay: 0.5 }}
              />
              <motion.circle 
                cx="100" cy="100" r="60" 
                stroke="url(#contactGrad)" 
                strokeWidth="0.5"
                initial={{ pathLength: 0, opacity: 0 }}
                animate={isInView ? { pathLength: 1, opacity: 1 } : {}}
                transition={{ duration: 2, delay: 0.7 }}
              />
              <motion.circle 
                cx="100" cy="100" r="40" 
                stroke="url(#contactGrad)" 
                strokeWidth="0.5"
                initial={{ pathLength: 0, opacity: 0 }}
                animate={isInView ? { pathLength: 1, opacity: 1 } : {}}
                transition={{ duration: 2, delay: 0.9 }}
              />
              <defs>
                <linearGradient id="contactGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#6366f1" stopOpacity="0.5" />
                  <stop offset="50%" stopColor="#a855f7" stopOpacity="0.3" />
                  <stop offset="100%" stopColor="#ec4899" stopOpacity="0.5" />
                </linearGradient>
              </defs>
            </svg>
          </div>
        </motion.div>

        <motion.footer 
          className="footer"
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ delay: 0.5, duration: 0.8 }}
        >
          <div className="footer-content">
            <div className="footer-brand">
              <span className="footer-logo">Jay</span>
              <span className="footer-divider"></span>
              <span className="footer-tagline">Web Developer</span>
            </div>
            <p className="footer-copyright">
              © 2024 Jay. Designed & Built with passion.
            </p>
          </div>
        </motion.footer>
      </div>
    </section>
  );
};

export default Contact;
