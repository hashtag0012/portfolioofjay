import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { 
  Zap, 
  MessageCircle, 
  Target, 
  Users, 
  Clock, 
  Shield 
} from 'lucide-react';

const reasons = [
  {
    icon: Zap,
    title: "Fast Turnaround",
    description: "24-48 hours for most tasks. I understand urgency and deliver quickly.",
    metric: "24-48h"
  },
  {
    icon: MessageCircle,
    title: "Clear Communication",
    description: "No jargon. Regular updates. Always accessible and responsive.",
    metric: "24/7"
  },
  {
    icon: Target,
    title: "Deadline Focused",
    description: "On-time delivery, every single time. Reliability you can count on.",
    metric: "100%"
  },
  {
    icon: Users,
    title: "Agency Experience",
    description: "Worked with agencies worldwide. I understand how teams operate.",
    metric: "5+ yrs"
  },
  {
    icon: Clock,
    title: "Flexible Hours",
    description: "Available for urgent work and ongoing projects. Your timeline matters.",
    metric: "Always"
  },
  {
    icon: Shield,
    title: "Quality Assured",
    description: "Clean code, tested features, no shortcuts. Premium quality work.",
    metric: "A+"
  }
];

const WhyMe = ({ onHover, onLeave }) => {
  const containerRef = useRef(null);
  const isInView = useInView(containerRef, { once: true, margin: "-100px" });

  const containerVariants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: 0.08
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, x: -40 },
    visible: {
      opacity: 1,
      x: 0,
      transition: {
        duration: 0.7,
        ease: [0.16, 1, 0.3, 1]
      }
    }
  };

  return (
    <section id="whyme" className="whyme-section" ref={containerRef}>
      <div className="container">
        <div className="whyme-layout">
          <motion.div 
            className="whyme-left"
            initial={{ opacity: 0, y: 40 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          >
            <span className="section-eyebrow">Why Me</span>
            <h2 className="section-title">
              Built on <span className="gradient-text">trust</span>,<br />
              proven by <span className="serif">results</span>
            </h2>
            <p className="whyme-description">
              I'm not just another developer. I'm a dedicated partner focused on 
              your success. Here's what sets me apart from the rest.
            </p>

            <motion.div 
              className="whyme-testimonial"
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.4, duration: 0.8 }}
            >
              <div className="testimonial-quote">"</div>
              <p className="testimonial-text">
                Jay delivered exactly what we needed, faster than expected. 
                His communication was excellent and the code quality was outstanding.
              </p>
              <div className="testimonial-author">
                <div className="author-avatar">JD</div>
                <div className="author-info">
                  <strong>John Doe</strong>
                  <span>CEO, TechStartup Inc.</span>
                </div>
              </div>
            </motion.div>
          </motion.div>

          <motion.div 
            className="whyme-right"
            variants={containerVariants}
            initial="hidden"
            animate={isInView ? "visible" : "hidden"}
          >
            {reasons.map((reason, index) => (
              <motion.div 
                key={index}
                className="reason-card"
                variants={itemVariants}
                onMouseEnter={onHover}
                onMouseLeave={onLeave}
              >
                <div className="reason-icon">
                  <reason.icon size={20} strokeWidth={1.5} />
                </div>
                <div className="reason-content">
                  <div className="reason-header">
                    <h3>{reason.title}</h3>
                    <span className="reason-metric">{reason.metric}</span>
                  </div>
                  <p>{reason.description}</p>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default WhyMe;
